<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <div class="row mb-0">
            <div class="col-lg-9 col-xl-6">
                <h4 class="mb-3"><?php echo e($pageTitle); ?></h4>
            </div>
            <div class="col-lg-3 col-xl-6">
                <ul class="list-inline mb-0 float-end">
                    <li class="list-inline-item">
                        <a href="<?php echo e(route('lombas.create')); ?>" class="btn btn-dark">
                            <i class="bi bi-plus-circle me-1"></i> Create Lomba
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="row d-flex justify-content-center">
            
            <?php $__currentLoopData = $lombas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lomba): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card mb-3 px-3 py-2" style="max-width: 540px;  margin: 10px">
                    <div class="row g-0">
                        <div class="col-md-4 d-flex justify-content-center align-items-center">
                            <img src="<?php echo e(asset('storage/files/' . $lomba->image)); ?>" class="img-fluid rounded shadow" alt="..." style="max-height: 180px;">
                        </div>
                        <div class="col-md-8">
                            <div class="card-body">
                                <p class="card-text"><small class="text-body-secondary">Lomba, <?php echo e($lomba->created_at); ?></small></p>
                                <h2 class="card-title" style="font-weight: bold"><?php echo e($lomba->name); ?></h2>
                                <p class="card-text overflow-hidden" style="max-height: 50px; height:50px"><?php echo e($lomba->description); ?></p>

                                
                                <div class="d-flex justify-content-end">
                                    <a href="<?php echo e(route('lombas.show', ['lomba' => $lomba->id])); ?>"
                                        class="btn btn-outline-dark btn-sm me-2"><i class="bi bi-info-circle"></i></a>
                                    <a href="<?php echo e(route('lombas.edit', ['lomba' => $lomba->id])); ?>"
                                        class="btn btn-outline-dark btn-sm me-2"><i class="bi-pencil-square"></i></a>
                                    <div>
                                        <form action="<?php echo e(route('lombas.destroy', ['lomba' => $lomba->id])); ?>"
                                            method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                            <button type="submit" class="btn btn-outline-dark btn-sm me-2 btn-delete"
                                                data-name="<?php echo e($lomba->name); ?>">
                                                <i class="bi-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_auth_nofooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Job\SI_UNS\resources\views/lomba/index.blade.php ENDPATH**/ ?>