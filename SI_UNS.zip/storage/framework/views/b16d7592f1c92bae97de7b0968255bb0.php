<?php $__env->startSection('content'); ?>
    <div class="container mt-5 mb-5">
        <span class="h1 fw-bold">
            List Lowongan Kerja
        </span>
        <p class="mt-3">
            Kesempatan Kerja Terbaik
        </p>
        <hr class="line-hr">

        
        <div class="row d-flex justify-content-center">
            
            <?php $__currentLoopData = $lokers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card mb-3 px-3 py-2 hover-card" style="max-width: 640px;  margin: 10px">
                    <div class="row g-0">
                        <div class="col-md-4 d-flex justify-content-center align-items-center">
                            <a href="<?php echo e(asset('storage/files/' . $loker->image)); ?>" target="_blank">
                                <img src="<?php echo e(asset('storage/files/' . $loker->image)); ?>" class="img-fluid rounded shadow"
                                    alt="..." style="max-height: 180px;">
                            </a>
                        </div>
                        <div class="col-md-8">
                            <div class="card-body">
                                <p class="card-text"><small class="text-body-secondary">Loker,
                                        <?php echo e($loker->created_at); ?></small></p>
                                <h2 class="card-title" style="font-weight: bold"><?php echo e($loker->name); ?></h2>
                                <p class="card-text overflow-hidden" style="max-height: 50px; height:50px">
                                    <?php echo e($loker->description); ?></p>

                                
                                <div class="d-flex justify-content-end">
                                    <a href="<?php echo e(route('guest.detail_loker', ['id' => $loker->id])); ?>"class="baca-selengkapnya fw-bold">
                                        Baca selengkapnya
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Job\SI_UNS\resources\views/guest/loker.blade.php ENDPATH**/ ?>